package com.bajaj.isdapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ISDadapter extends RecyclerView.Adapter<ISDadapter.ISDholder> implements Filterable {
    private List<ISD> isds = new ArrayList<>();
    private List<ISD> isdsFull;
    private OnItemClickListener listener;

    @NonNull
    @Override
    public ISDholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.isd_item, parent, false);
        return new ISDholder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ISDholder holder, int position) {
        ISD currentISD = isds.get(position);
        holder.textViewName.setText(currentISD.getName());
        holder.textViewaddress.setText(currentISD.getAddress());
        holder.textViewMobileNo.setText(currentISD.getMob_num());
        holder.textViewGender.setText(currentISD.getGender());
        holder.textViewCity.setText(currentISD.getCity());
    }

    @Override
    public int getItemCount() {
        return isds.size();
    }

    public void setIsds(List<ISD> isds) {
        this.isds = isds;
        isdsFull = new ArrayList<>(isds);
        notifyDataSetChanged();
    }

    public ISD getISDat(int position) {
        return isds.get(position);
    }

    class ISDholder extends RecyclerView.ViewHolder {
        private TextView textViewName;
        private TextView textViewaddress;
        private TextView textViewMobileNo;
        private TextView textViewGender;
        private TextView textViewCity;

        public ISDholder(@NonNull View itemView) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.isd_name);
            textViewaddress = itemView.findViewById(R.id.isd_address);
            textViewGender = itemView.findViewById(R.id.isd_gender);
            textViewCity = itemView.findViewById(R.id.isd_city);
            textViewMobileNo = itemView.findViewById(R.id.isd_mobile_no);


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    if(listener != null && position != RecyclerView.NO_POSITION) {
                        listener.onItemClick(isds.get(position));
                    }
                }
            });
        }
    }

    public interface OnItemClickListener {
        void onItemClick(ISD isd);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    @Override
    public Filter getFilter() {
        return isdsFilter;
    }

    private Filter isdsFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {
            List<ISD> filteredList = new ArrayList<>();
            if(charSequence == null || charSequence.length() == 0) {
                filteredList.addAll(isdsFull);
            } else {
                String filterPattern = charSequence.toString().trim();

                for(ISD isd : isdsFull) {
                    if(isd.getMob_num().contains(filterPattern)) {
                        filteredList.add(isd);
                    }
                }
            }
            FilterResults results = new FilterResults();
            results.values = filteredList;
            return results;
        }

        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
            isds.clear();
            isds.addAll((List) filterResults.values);
            notifyDataSetChanged();
        }
    };
}