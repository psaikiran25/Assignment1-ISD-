package com.bajaj.isdapp;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface JsonPlaceHolderApi {

    @Headers({"Content-Type: application/json",
            "Ocp-Apim-Subscription-Key: 223f900e901a4a61baedc803eef5153b"})
    @POST("SendOTP")
    Call<SendOtpResponse> getOtp(@Body SendOtpBody sendOtpBody);


    @Headers({"Content-Type: application/json",
            "Ocp-Apim-Subscription-Key: 223f900e901a4a61baedc803eef5153b"})
    @POST("ValidateOTP")
    Call<ValidateOtpResponse> validateOtp(@Body ValidateOtpBody validateOtpBody);

}
