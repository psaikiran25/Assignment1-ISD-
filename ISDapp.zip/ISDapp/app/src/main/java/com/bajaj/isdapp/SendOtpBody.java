package com.bajaj.isdapp;

public class SendOtpBody {
    private String mobileNumber;
    private String otpSource;
    private String module;

    public SendOtpBody(String mobileNumber, String otpSource, String module) {
        this.mobileNumber = mobileNumber;
        this.otpSource = otpSource;
        this.module = module;
    }
}
