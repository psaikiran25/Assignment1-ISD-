package com.bajaj.isdapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

public class DashBoardActivity extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {

    private TextView textViewTodayLogins;
    private TextView textViewMaleLogins;
    private TextView textViewFemaleLogins;
    private TextView textViewOtherLogins;

    private TextView textTodaysLogins;

    HashMap<String, Integer> dailyLogins = new HashMap<>();
    HashMap<String, Integer> genderLogins = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash_board);

        setTitle("Dashboard");
        Intent intent = getIntent();

        ArrayList<Dashboard> dashboardList = (ArrayList<Dashboard>) intent.getSerializableExtra(MainActivity.EXTRA_DASHBOARD);

        genderLogins.put("Male", 0);
        genderLogins.put("Female", 0);
        genderLogins.put("Other", 0);

        for(Dashboard dashboard : dashboardList) {
            String key = dashboard.getDate_of_creation();
            if(dailyLogins.containsKey(key)) {
                Integer value = dailyLogins.get(key);
                dailyLogins.put(key, value + 1);
            } else {
                dailyLogins.put(key, 1);
            }

            String gender = dashboard.getGender();
            genderLogins.put(gender, genderLogins.get(gender) + 1);
        }

        textViewTodayLogins = findViewById(R.id.textview_todays_login);
        textViewMaleLogins = findViewById(R.id.textview_male_logins);
        textViewFemaleLogins = findViewById(R.id.textview_female_logins);
        textViewOtherLogins = findViewById(R.id.textview_other_logins);
        textTodaysLogins = findViewById(R.id.text_todays_login);

        Date date = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String todaysDate = dateFormat.format(date);

//        if(dailyLogins.containsKey(todaysDate)) {
//            String value = dailyLogins.get(todaysDate).toString();
//            textViewTodayLogins.setText(value);
//        } else textViewTodayLogins.setText("0");

        textViewTodayLogins.setText(Integer.toString(getPickedDateLogins(todaysDate)));

        try {
            textViewMaleLogins.setText(genderLogins.get("Male").toString());
            textViewFemaleLogins.setText(genderLogins.get("Female").toString());
            textViewOtherLogins.setText(genderLogins.get("Other").toString());
        } catch (Exception e) {
            Log.d("Exception", e.getMessage());
        }

        ImageView datepickerBtn = findViewById(R.id.imageview_datepicker);
        datepickerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogFragment datePicker = new DatePickerFragment();
                datePicker.show(getSupportFragmentManager(), "date picker");
            }
        });
    }

    @Override
    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {

        String pickedDate = "";
        pickedDate += Integer.toString(i) + "-";
        pickedDate += Integer.toString(i1+1) + "-";
        pickedDate += Integer.toString(i2);
        Log.d("pickedDate", pickedDate);

        textViewTodayLogins.setText(Integer.toString(getPickedDateLogins(pickedDate)));
        textTodaysLogins.setText(pickedDate + "'s Logins");
    }

    private int getPickedDateLogins(String pickedDate) {
        int logins = 0;

        if(dailyLogins.containsKey(pickedDate)) {
            logins = dailyLogins.get(pickedDate);
//            textViewTodayLogins.setText(value);
        }

        return logins;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
        }
        return super.onOptionsItemSelected(item);
    }
}