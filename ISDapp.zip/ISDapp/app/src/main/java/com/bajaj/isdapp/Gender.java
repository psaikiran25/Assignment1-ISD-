package com.bajaj.isdapp;

public enum Gender {
    Male,
    Female,
    Other
}
