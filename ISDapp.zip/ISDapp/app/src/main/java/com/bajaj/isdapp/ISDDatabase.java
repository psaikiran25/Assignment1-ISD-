package com.bajaj.isdapp;

import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

@Database(entities = ISD.class, version = 1)
public abstract class ISDDatabase extends RoomDatabase {

    private static ISDDatabase instance;

    public abstract ISDdao isdDao();

    public static synchronized ISDDatabase getInstance(Context context) {
        if(instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    ISDDatabase.class, "isd_database")
                    .fallbackToDestructiveMigration()
                    .addCallback(roomCallback)
                    .build();
        }
        return instance;
    }

    private static RoomDatabase.Callback roomCallback = new RoomDatabase.Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
//            new PopulateDbAsyncTask(instance).execute();
        }
    };

    private static class PopulateDbAsyncTask extends AsyncTask<Void,Void,Void> {
        private ISDdao isdDao;

        private PopulateDbAsyncTask(ISDDatabase db) {
            isdDao = db.isdDao();
        }

        @Override
        protected Void doInBackground(Void... voids) {

            Date date = Calendar.getInstance().getTime();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss.SSS");
            String dateAndTime = dateFormat.format(date);
            isdDao.insert(new ISD("sk", "male", "12345667890",
                    "Main Street", "Pune", dateAndTime));
            isdDao.insert(new ISD("sk2", "male", "12345667890",
                    "Main Street", "Pune", dateAndTime));
            return null;
        }
    }
}
