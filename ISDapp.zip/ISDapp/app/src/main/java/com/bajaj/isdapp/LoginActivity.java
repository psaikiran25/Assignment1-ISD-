package com.bajaj.isdapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class LoginActivity extends AppCompatActivity {

    private TextInputLayout editTextPhoneNo;
    private TextInputLayout editTextOtp;
    private Button buttonGetOtp;
    private Button buttonLogin;

    private OkHttpClient okHttpClient;
    private JsonPlaceHolderApi jsonPlaceHolderApi;
    private TimeApi timeApi;

    public static final String SHARED_PREFS = "shared_prefs";
    public static final String LAST_LOGIN_TIME = "last_login_time";

    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_screen);

        getSupportActionBar().hide();

//        Intent intent = new Intent(this, MainActivity.class);
//        startActivity(intent);
//        finish();

        if (isNetworkConnected()) {

            HttpLoggingInterceptor httpLoggingInterceptor = new HttpLoggingInterceptor();
            httpLoggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);

            okHttpClient = new OkHttpClient.Builder()
                    .addInterceptor(httpLoggingInterceptor)
                    .build();

            Retrofit retrofittime = new Retrofit.Builder()
                    .baseUrl("http://worldtimeapi.org/api/timezone/")
                    .addConverterFactory(GsonConverterFactory.create())
                    .client(okHttpClient)
                    .build();

            timeApi = retrofittime.create(TimeApi.class);

            Log.d("getTime", "calling getTime..");

            getTime();

        } else {
            Toast.makeText(LoginActivity.this, "Please connect to a network and try again", Toast.LENGTH_SHORT).show();
        }
    }

    private void checkIfLoggedIn(String currentTime) {

        sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        String lastLoginTime = sharedPreferences.getString(LAST_LOGIN_TIME, "");

        Log.d("lastLoginTime", lastLoginTime);

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
        Date date;

        if(currentTime == "" || lastLoginTime == "") {
            Log.d("enableLogin", "Check point 4" );
            enableLogin();
            return;
        }

        long currentTimeMillis = 0;
        try {
            date = simpleDateFormat.parse(currentTime);
            currentTimeMillis = date.getTime();
            Log.d("currentTimeMillis", Long.toString(currentTimeMillis));

        } catch (ParseException e) {
            e.printStackTrace();
            Log.d("enableLogin", "Check point 5" );
            enableLogin();
            return;
        }

        long loginTimeMillis = 0;
        try {
            date = simpleDateFormat.parse(lastLoginTime);
            loginTimeMillis = date.getTime();
            Log.d("loginTimeMillis", Long.toString(loginTimeMillis));

        } catch (ParseException e) {
            e.printStackTrace();
            Log.d("enableLogin", "Check point 6" );
            enableLogin();
            return;
        }

        long timeDifference = currentTimeMillis - loginTimeMillis;

        Log.d("timeDifference", Long.toString(timeDifference));

        if (timeDifference < 1800000 && timeDifference > 0) {
            Log.d("New Activity", "Opening MainActivity");
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        } else {
            Log.d("enableLogin", "Check point 7");
            enableLogin();
        }

    }

    public void enableLogin() {

        setContentView(R.layout.activity_login);
        getSupportActionBar().show();

        editTextPhoneNo = findViewById(R.id.edittext_phoneNo);
        editTextOtp = findViewById(R.id.edittext_otp);
        buttonGetOtp = findViewById(R.id.getOtpBtn);
        buttonLogin = findViewById(R.id.loginBtn);

        if(isNetworkConnected()) {
            buttonGetOtp.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String phoneNo = editTextPhoneNo.getEditText().getText().toString();
                    if (phoneNo.trim().length() != 10) {
                        Toast.makeText(LoginActivity.this, "Please Enter Valid Mobile Number", Toast.LENGTH_SHORT).show();
                    } else {

                        Retrofit retrofit = new Retrofit.Builder()
                                .baseUrl("https://prodapitm.bajajfinserv.in/ServiceAPPWS_Session/")
                                .addConverterFactory(GsonConverterFactory.create())
                                .client(okHttpClient)
                                .build();

                        SendOtpBody sendOtpBody = new SendOtpBody(
                                phoneNo, "MOBAPP", "LITEAPP");

                        jsonPlaceHolderApi = retrofit.create(JsonPlaceHolderApi.class);

                        sendOtp(sendOtpBody);
                    }
                }
            });
        } else Toast.makeText(this, "Please connect to a Network and try again", Toast.LENGTH_SHORT).show();
    }

    private void getTime() {
        
        if(isNetworkConnected()) {

            Call<Time> call = timeApi.getTime();

            call.enqueue(new Callback<Time>() {
                @Override
                public void onResponse(Call<Time> call, Response<Time> response) {
                    if (!response.isSuccessful()) {
                        Log.d("enableLogin", "Check point 1" );
                        enableLogin();
                        return;
                    }

                    Time time = response.body();

                    if (time.getError() != null) {
                        Log.d("enableLogin", "Check point 2" );
                        enableLogin();
                        return;
                    }

                    String currentTimeString = time.getDatetime();
                    String currentTime = currentTimeString.substring(0, 10) + " "
                            + currentTimeString.substring(11, 23);

                    Log.d("currentTimeString", currentTimeString);
                    Log.d("currentTime", currentTime);

                    checkIfLoggedIn(currentTime);
                }

                @Override
                public void onFailure(Call<Time> call, Throwable t) {
//                    Toast.makeText(LoginActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
                    Log.d("enableLogin", "Check point 3" );
                    enableLogin();
                }
            });
        } else Toast.makeText(this, "Please connect to a network and try again", Toast.LENGTH_SHORT).show();

        return;
    }

    private void sendOtp(final SendOtpBody sendOtpBody) {

        Call<SendOtpResponse> call = jsonPlaceHolderApi.getOtp(sendOtpBody);

        call.enqueue(new Callback<SendOtpResponse>() {
            @Override
            public void onResponse(Call<SendOtpResponse> call, Response<SendOtpResponse> response) {
                if(!response.isSuccessful()) {
                    Toast.makeText(LoginActivity.this,
                            "Something went wrong, try again later 1", Toast.LENGTH_SHORT).show();
                    return;
                }

                final SendOtpResponse sendOtpResponse = response.body();

//                Log.d("response1", response.toString());
//                Log.d("sendOtpResponse", sendOtpResponse.getErrorMsg());

//                if(sendOtpResponse.getErrorCode().trim() == "OTP Sent Successfully") {
//                    Toast.makeText(LoginActivity.this,
//                            "Something went wrong, try again later 2", Toast.LENGTH_SHORT).show();
//                    return;
//                }

                editTextOtp.setVisibility(View.VISIBLE);
                buttonLogin.setVisibility(View.VISIBLE);
                
                if(isNetworkConnected()) {

                    buttonLogin.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            
                            String otp = editTextOtp.getEditText().getText().toString();
                            
                            if (otp.trim().length() != 6) {
                                Toast.makeText(LoginActivity.this,
                                        "Enter a valid 6-digit OTP", Toast.LENGTH_SHORT).show();
                                return;
                            }
                            
                            ValidateOtpBody validateOtpBody = new ValidateOtpBody(
                                    sendOtpResponse.getMobileNo(),
                                    otp,
                                    "MobApp",
                                    sendOtpResponse.getRequestID()
                            );
                            validateOtp(validateOtpBody);
                        }
                    });
                } else Toast.makeText(LoginActivity.this, "Please connect to a network and try again", Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onFailure(Call<SendOtpResponse> call, Throwable t) {
                Toast.makeText(LoginActivity.this,
                        "Error occured, try again later 3"
                        + "\n" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void validateOtp(final ValidateOtpBody validateOtpBody) {

        Call<ValidateOtpResponse> call = jsonPlaceHolderApi.validateOtp(validateOtpBody);
        
        if(isNetworkConnected()) {

            call.enqueue(new Callback<ValidateOtpResponse>() {
                @Override
                public void onResponse(Call<ValidateOtpResponse> call, Response<ValidateOtpResponse> response) {
                    if (!response.isSuccessful()) {
                        Toast.makeText(LoginActivity.this,
                                "Something went wrong, try again later 4", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    ValidateOtpResponse validateOtpResponse = response.body();

                    if (validateOtpResponse.getErrorCode() == 0) {
                        String loginTime = validateOtpResponse.getRequestID().substring(6);

                        sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();

                        editor.putString(LAST_LOGIN_TIME, loginTime);
                        editor.apply();

                        Log.d("shared preference", loginTime);

                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                        startActivity(intent);
                        finish();

                        return;

                    } else if (validateOtpResponse.getErrorDesc().trim() == "OTP NUMBER DO NOT MATCH") {
                        Toast.makeText(LoginActivity.this,
                                "OTP Not Valid, Please try again", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(LoginActivity.this,
                                "Something went wrong, try again later 5", Toast.LENGTH_SHORT).show();
                    }

                }

                @Override
                public void onFailure(Call<ValidateOtpResponse> call, Throwable t) {
                    Toast.makeText(LoginActivity.this,
                            "Error occured, try again later 6"
                                    + "\n" + t.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        } else Toast.makeText(this, "Please connect to a network and try again", Toast.LENGTH_SHORT).show();
    }

    public boolean isNetworkConnected() {

        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = cm.getActiveNetworkInfo();
        return networkInfo != null && networkInfo.isConnected();
    }
}