package com.bajaj.isdapp;

public class Time {
    private String datetime;
    private String error;

    public String getDatetime() {
        return datetime;
    }

    public String getError() {
        return error;
    }
}
