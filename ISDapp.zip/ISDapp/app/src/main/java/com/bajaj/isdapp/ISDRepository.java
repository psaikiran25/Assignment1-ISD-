package com.bajaj.isdapp;

import android.app.Application;
import android.os.AsyncTask;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.room.Delete;

import java.util.List;

public class ISDRepository {
    private ISDdao isdDao;
    private LiveData<List<ISD>> allISDs;
    private LiveData<List<Dashboard>> dashboardData;

    public ISDRepository(Application application) {
        ISDDatabase database = ISDDatabase.getInstance(application);
        isdDao = database.isdDao();
        allISDs = isdDao.getAllISDs();
//        Log.d("allISDs at repository", allISDs.getValue().toString());
        dashboardData = isdDao.getDashBoardData();
//        Log.d("dashboardData at repo", dashboardData.getValue().toString());
    }

    public void insert(ISD isd) {
        new InsertISDAsyncTask(isdDao).execute(isd);
    }

    public void update(ISD isd) {
        new UpdateISDAsyncTask(isdDao).execute(isd);
    }

    public void delete(ISD isd) {
        new DeleteISDAsyncTask(isdDao).execute(isd);
    }

    public void deleteAllISDs() {
        new DeleteAllISDAsyncTask(isdDao).execute();
    }

    public LiveData<List<ISD>> getAllISDs() {
        return allISDs;
    }

//    public LiveData<List<Dashboard>> getDashboardData() {
//        return dashboardData;
//    }

    private static class InsertISDAsyncTask extends AsyncTask<ISD, Void, Void> {
        private ISDdao isdDao;

        private InsertISDAsyncTask(ISDdao isdDao) {
            this.isdDao = isdDao;
        }

        @Override
        protected Void doInBackground(ISD... isds) {
            isdDao.insert(isds[0]);
            return null;
        }
    }

    private static class UpdateISDAsyncTask extends AsyncTask<ISD, Void, Void> {
        private ISDdao isdDao;

        private UpdateISDAsyncTask(ISDdao isdDao) {
            this.isdDao = isdDao;
        }

        @Override
        protected Void doInBackground(ISD... isds) {
            isdDao.update(isds[0]);
            return null;
        }
    }

    private static class DeleteISDAsyncTask extends AsyncTask<ISD, Void, Void> {
        private ISDdao isdDao;

        private DeleteISDAsyncTask(ISDdao isdDao) {
            this.isdDao = isdDao;
        }

        @Override
        protected Void doInBackground(ISD... isds) {
            isdDao.delete(isds[0]);
            return null;
        }
    }

    private static class DeleteAllISDAsyncTask extends AsyncTask<Void, Void, Void> {
        private ISDdao isdDao;

        private DeleteAllISDAsyncTask(ISDdao isdDao) {
            this.isdDao = isdDao;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            isdDao.deleteAllISDs();
            return null;
        }
    }
}
