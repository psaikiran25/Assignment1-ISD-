package com.bajaj.isdapp;

public class ValidateOtpBody {
    private String mobileNumber;
    private String otp;
    private String otpSource;
    private String requestID;

    public ValidateOtpBody(String mobileNumber, String otp, String otpSource, String requestID) {
        this.mobileNumber = mobileNumber;
        this.otp = otp;
        this.otpSource = otpSource;
        this.requestID = requestID;
    }
}
