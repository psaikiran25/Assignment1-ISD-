package com.bajaj.isdapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.SearchView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    public static final int ADD_ISD_REQUEST = 1;
    public static final int EDIT_ISD_REQUEST = 2;

    public static final String EXTRA_DASHBOARD = "EXTRA_DASHBOARD";

    public ISDViewModel isdViewModel;
    ISDadapter adapter = new ISDadapter();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FloatingActionButton buttonAddIsd = findViewById(R.id.button_add_isd);
        buttonAddIsd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddEditIsdActivity.class);
                startActivityForResult(intent, ADD_ISD_REQUEST);
            }
        });

        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

//        final ISDadapter adapter = new ISDadapter();
        recyclerView.setAdapter(adapter);

//        isdViewModel = new ViewModelProvider(this).get(ISDViewModel.class);
        ViewModelProvider.Factory factory = ViewModelProvider.AndroidViewModelFactory.getInstance(getApplication());
        isdViewModel = new ViewModelProvider(this, factory).get(ISDViewModel.class);

        isdViewModel.getAllISDs().observe(this, new Observer<List<ISD>>() {
            @Override
            public void onChanged(@Nullable List<ISD> isds) {
                adapter.setIsds(isds);
            }
        });

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                isdViewModel.delete(adapter.getISDat(viewHolder.getAdapterPosition()));
                Toast.makeText(MainActivity.this, "ISD Deleted", Toast.LENGTH_SHORT).show();
            }
        }).attachToRecyclerView(recyclerView);

        adapter.setOnItemClickListener(new ISDadapter.OnItemClickListener() {
            @Override
            public void onItemClick(ISD isd) {
                Intent intent = new Intent(MainActivity.this, AddEditIsdActivity.class);

                intent.putExtra(AddEditIsdActivity.EXTRA_ID, isd.getId());
                intent.putExtra(AddEditIsdActivity.EXTRA_NAME, isd.getName());
                intent.putExtra(AddEditIsdActivity.EXTRA_GENDER, isd.getGender());
                intent.putExtra(AddEditIsdActivity.EXTRA_ADDRESS, isd.getAddress());
                intent.putExtra(AddEditIsdActivity.EXTRA_MOBILE_NO, isd.getMob_num());
                intent.putExtra(AddEditIsdActivity.EXTRA_CITY, isd.getCity());

                startActivityForResult(intent, EDIT_ISD_REQUEST);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        Log.d("requestCode", Integer.toString(requestCode));

        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == ADD_ISD_REQUEST && resultCode == RESULT_OK) {

            String name = data.getStringExtra(AddEditIsdActivity.EXTRA_NAME);
            String address = data.getStringExtra(AddEditIsdActivity.EXTRA_ADDRESS);
            String gender = data.getStringExtra(AddEditIsdActivity.EXTRA_GENDER);
            String mobile_no = data.getStringExtra(AddEditIsdActivity.EXTRA_MOBILE_NO);
            String city = data.getStringExtra(AddEditIsdActivity.EXTRA_CITY);

            Date date = Calendar.getInstance().getTime();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
            String dateAndTime = dateFormat.format(date);

            ISD isd = new ISD(name, gender, mobile_no, address, city, dateAndTime);
            isdViewModel.insert(isd);

            Toast.makeText(this, "ISD saved", Toast.LENGTH_SHORT).show();
//            Toast.makeText(this, "at" + dateAndTime, Toast.LENGTH_SHORT).show();

        } else if (requestCode == EDIT_ISD_REQUEST && resultCode == RESULT_OK) {

            int id = data.getIntExtra(AddEditIsdActivity.EXTRA_ID, -1);

            if (id == -1) {
                Toast.makeText(this, "ISD can't be updated", Toast.LENGTH_SHORT).show();
                return;
            }

            String name = data.getStringExtra(AddEditIsdActivity.EXTRA_NAME);
            String address = data.getStringExtra(AddEditIsdActivity.EXTRA_ADDRESS);
            String gender = data.getStringExtra(AddEditIsdActivity.EXTRA_GENDER);
            String mobile_no = data.getStringExtra(AddEditIsdActivity.EXTRA_MOBILE_NO);
            String city = data.getStringExtra(AddEditIsdActivity.EXTRA_CITY);

            Date date = Calendar.getInstance().getTime();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
            String dateAndTime = dateFormat.format(date);

            ISD isd = new ISD(name, gender, mobile_no, address, city, dateAndTime);

            isd.setId(id);

            isdViewModel.update(isd);

            Toast.makeText(this, "ISD updated", Toast.LENGTH_SHORT).show();
//            Toast.makeText(this, "at" + dateAndTime, Toast.LENGTH_SHORT).show();
            Log.d("updated at", dateAndTime);

        } else {
            if(requestCode == EDIT_ISD_REQUEST) {
                Toast.makeText(this, "ISD not updated", Toast.LENGTH_SHORT).show();
            }
            if(requestCode == ADD_ISD_REQUEST) {
                Toast.makeText(this, "ISD not saved", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.delete_all_isds: {

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
                alertDialogBuilder.setTitle("Delete All?");
                alertDialogBuilder.setMessage("Are you sure you want to delete all the ISDs");
                alertDialogBuilder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        isdViewModel.deleteAllISDs();
                        Toast.makeText(MainActivity.this, "All ISDs deleted", Toast.LENGTH_SHORT).show();
                    }

                });
                alertDialogBuilder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        return;
                    }
                });
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
                return true;
            }
            case R.id.logout: {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
                alertDialogBuilder.setTitle("Logout?");
                alertDialogBuilder.setMessage("Are you sure you want to logout");
                alertDialogBuilder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        SharedPreferences sharedPreferences = getSharedPreferences(LoginActivity.SHARED_PREFS, MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();

                        editor.putString(LoginActivity.LAST_LOGIN_TIME, "");
                        editor.apply();

                        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                        startActivity(intent);
                        finish();

                        Toast.makeText(MainActivity.this, "You've been logged out successfully", Toast.LENGTH_LONG).show();
                    }
                });
                alertDialogBuilder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        return;
                    }
                });
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
                return true;
            }

            case R.id.search_isd: {

                SearchView searchView = (SearchView) item.getActionView();

                searchView.setImeOptions(EditorInfo.IME_ACTION_DONE);
                searchView.setInputType(EditorInfo.TYPE_CLASS_NUMBER);

                searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String s) {
                        return false;
                    }

                    @Override
                    public boolean onQueryTextChange(String s) {
                        adapter.getFilter().filter(s);
                        return false;
                    }
                });
                return true;
            }

            case R.id.dash_board: {

                List<ISD> isdList = isdViewModel.getAllISDs().getValue();
                List<Dashboard> dashboardList = new ArrayList<>();

                for (ISD isd:isdList) {
                    String gender = isd.getGender();
                    String doc = isd.getDate_of_creation().substring(0,10);
                    Dashboard dashboard = new Dashboard(gender, doc);
                    dashboardList.add(dashboard);
                }

                Intent intent = new Intent(MainActivity.this, DashBoardActivity.class);
                intent.putExtra(EXTRA_DASHBOARD, (Serializable) dashboardList);
                startActivity(intent);
            }

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}