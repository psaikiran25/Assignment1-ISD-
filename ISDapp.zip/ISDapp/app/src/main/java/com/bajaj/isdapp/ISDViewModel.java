package com.bajaj.isdapp;

import android.app.Application;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class ISDViewModel extends AndroidViewModel {

    private ISDRepository repository;
    private LiveData<List<ISD>> allISDs;
    private LiveData<List<Dashboard>> dashboardData;

    public ISDViewModel(@NonNull Application application) {
        super(application);
        repository = new ISDRepository(application);
        allISDs = repository.getAllISDs();
//        Log.d("allISDs at viewmodel", allISDs.getValue().toString());
//        dashboardData = repository.getDashboardData();
//        Log.d("dashboardData at view", dashboardData.getValue().toString());
    }

    public void insert(ISD isd) {
        repository.insert(isd);
    }

    public void update(ISD isd) {
        repository.update(isd);
    }

    public void delete(ISD isd) {
        repository.delete(isd);
    }

    public void deleteAllISDs() {
        repository.deleteAllISDs();
    }

    public LiveData<List<ISD>> getAllISDs() {
        return allISDs;
    }

//    public LiveData<List<Dashboard>> getDashboardData() {
//        return dashboardData;
//    }
}
