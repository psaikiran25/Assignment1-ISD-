package com.bajaj.isdapp;

import com.google.gson.annotations.SerializedName;

public class SendOtpResponse {

    private String errorCode;

    private String errorMsg;

    @SerializedName("mobile_No__c")
    private String mobileNo;

    private String requestID;

    public String getErrorCode() {
        return errorCode;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public String getRequestID() {
        return requestID;
    }
}
