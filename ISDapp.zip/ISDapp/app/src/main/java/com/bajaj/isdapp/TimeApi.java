package com.bajaj.isdapp;

import retrofit2.Call;
import retrofit2.http.GET;

public interface TimeApi {

    @GET("Asia/Kolkata")
    Call<Time> getTime();
}
