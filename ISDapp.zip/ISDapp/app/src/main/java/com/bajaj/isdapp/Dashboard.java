package com.bajaj.isdapp;

import java.io.Serializable;

public class Dashboard implements Serializable {
    private String gender;
    private String date_of_creation;

    public Dashboard(String gender, String date_of_creation) {
        this.gender = gender;
        this.date_of_creation = date_of_creation;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setDate_of_creation(String date_of_creation) {
        this.date_of_creation = date_of_creation;
    }

    public String getGender() {
        return gender;
    }

    public String getDate_of_creation() {
        return date_of_creation;
    }
}
