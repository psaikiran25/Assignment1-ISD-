package com.bajaj.isdapp;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.Date;

@Entity(tableName = "isd_table")
public class ISD {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String name;

    private String gender;

    private String mob_num;

    private String address;

    private String city;

    private String date_of_creation;

    public ISD(String name, String gender, String mob_num, String address, String city, String date_of_creation ) {
        this.name = name;
        this.gender = gender;
        this.mob_num = mob_num;
        this.address = address;
        this.city = city;
        this.date_of_creation = date_of_creation;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getGender() {
        return gender;
    }

    public String getMob_num() {
        return mob_num;
    }

    public String getAddress() {
        return address;
    }

    public String getCity() {
        return city;
    }

    public String getDate_of_creation() {
        return date_of_creation;
    }

}
