package com.bajaj.isdapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class AddEditIsdActivity extends AppCompatActivity {
    public static final String EXTRA_NAME = "EXTRA_NAME";
    public static final String EXTRA_GENDER = "EXTRA_GENDER";
    public static final String EXTRA_ADDRESS = "EXTRA_ADDRESS";
    public static final String EXTRA_CITY = "EXTRA_CITY";
    public static final String EXTRA_MOBILE_NO = "EXTRA_MOBILE_NO";
    public static final String EXTRA_ID = "EXTRA_ID";

    private EditText editTextName;
    private EditText editTextAddress;
    private EditText editTextMobileNo;
    private EditText editTextCity;
    private RadioGroup radioGroupGender;
    private RadioButton radioButtonGender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_isd);

        editTextName = findViewById(R.id.edittext_name);
        editTextAddress = findViewById(R.id.edittext_address);
        editTextMobileNo = findViewById(R.id.edittext_mobile_no);
        editTextCity = findViewById(R.id.edittext_city);

        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_close);

        Intent intent = getIntent();

        if(intent.hasExtra(EXTRA_ID)) {

            setTitle("Edit ISD");

            editTextName.setText(intent.getStringExtra(EXTRA_NAME));
            editTextAddress.setText(intent.getStringExtra(EXTRA_ADDRESS));
            editTextMobileNo.setText(intent.getStringExtra(EXTRA_MOBILE_NO));
            editTextCity.setText(intent.getStringExtra(EXTRA_CITY));

            radioGroupGender = findViewById(R.id.radiogrp_gender);

            int count = radioGroupGender.getChildCount();

            RadioButton radioButton = (RadioButton) radioGroupGender.getChildAt(0);
            radioButton.setChecked(true);

            for(int i = 0; i < count; i++) {
                radioButton = (RadioButton) radioGroupGender.getChildAt(i);
                if(radioButton.getText().toString() == intent.getStringExtra(EXTRA_GENDER)) {
                    radioButton.setChecked(true);
//                    ((RadioButton) radioGroupGender.getChildAt(i)).setChecked(true);
                    break;
                }
            }
        } else {
            setTitle("Add ISD");
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.add_isd_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.save_isd :
                saveNote();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void saveNote() {

        String name = editTextName.getText().toString();
        String mobileNo = editTextMobileNo.getText().toString();
        String gender = "";
        String city = editTextCity.getText().toString();
        String address = editTextAddress.getText().toString();

        radioGroupGender = findViewById(R.id.radiogrp_gender);
        radioButtonGender = findViewById(radioGroupGender.getCheckedRadioButtonId());

        if(radioButtonGender == null) {
            gender = "Male";
        } else gender = radioButtonGender.getText().toString();


        if(name.trim().isEmpty() ||
                address.trim().isEmpty() ||
                mobileNo.trim().isEmpty() ||
                city.trim().isEmpty() ||
                radioButtonGender == null) {
            Toast.makeText(this, "Please fill all the details", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent data = new Intent();
        data.putExtra(AddEditIsdActivity.EXTRA_NAME, name);
        data.putExtra(AddEditIsdActivity.EXTRA_ADDRESS, address);
        data.putExtra(AddEditIsdActivity.EXTRA_GENDER, gender);
        data.putExtra(AddEditIsdActivity.EXTRA_CITY, city);
        data.putExtra(AddEditIsdActivity.EXTRA_MOBILE_NO, mobileNo);

        int id = getIntent().getIntExtra(EXTRA_ID, -1);

        if(id != -1) {
            data.putExtra(EXTRA_ID, id);
        }

        setResult(RESULT_OK, data);
        finish();
    }
}
