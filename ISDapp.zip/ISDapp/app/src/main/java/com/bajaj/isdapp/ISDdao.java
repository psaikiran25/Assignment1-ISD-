package com.bajaj.isdapp;

import android.icu.util.IslamicCalendar;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ISDdao {

    @Insert
    void insert(ISD isd);

    @Update
    void update(ISD isd);

    @Delete
    void delete(ISD isd);

    @Query("DELETE FROM isd_table")
    void deleteAllISDs();

    @Query("SELECT * FROM isd_table ORDER BY date_of_creation DESC")
    LiveData<List<ISD>> getAllISDs();

    @Query("SELECT gender, date_of_creation FROM isd_table")
    LiveData<List<Dashboard>> getDashBoardData();


}
