package com.bajaj.isdapp;

public class ValidateOtpResponse {
    private int errorCode;
    private String errorDesc;
    private String requestID;

    public int getErrorCode() {
        return errorCode;
    }

    public String getErrorDesc() {
        return errorDesc;
    }

    public String getRequestID() {
        return requestID;
    }
}
